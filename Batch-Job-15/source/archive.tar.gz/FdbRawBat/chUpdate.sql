use job15;
create table shell_example
(id INT ,
username VARCHAR(100),
password varchar(100));