use job15;

insert into shell_example values (101,'udajhvd','jasd');
insert into shell_example values (103,'skjx','jasd'); 