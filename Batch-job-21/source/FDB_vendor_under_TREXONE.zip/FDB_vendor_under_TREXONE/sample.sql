use job15;

insert into shell_example values (104,'udayvarma','jasd');
insert into shell_example values (105,'udayvarma','jasd'); 